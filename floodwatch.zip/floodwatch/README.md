# FloodWatch 🌊
**Real-time flood prediction for low-income coastal communities**

SMS alerts via satellite data + machine learning. Fully open-source. Runs for under $50/month for a community of 10,000.

---

## How it works

```
Sentinel-1 SAR (soil moisture)  ─┐
NOAA GFS forecast (rain 24h)    ─┤─▶ Risk score (0–100) ─▶ SMS alert (Twilio)
SRTM elevation model            ─┤                       ─▶ Live dashboard
Coastal distance (static)       ─┘
```

A logistic regression model trained on 2015–2023 Bangladesh flood records scores each region every 6 hours. Yellow alert (score >60) = prepare. Red alert (score >80) = evacuate.

---

## Quick start

### 1. Clone and install
```bash
git clone https://github.com/your-username/floodwatch
cd floodwatch
pip install -r requirements.txt
```

### 2. Configure
```bash
cp .env.template .env
# Edit .env with your Twilio credentials and GEE service account
```

### 3. Add your regions
Edit `pipeline.py` → `CONFIG["target_regions"]`:
```python
{"name": "Your Region", "lat": 13.75, "lon": 100.50, "radius_km": 20}
```

Add terrain data in `alerts/sms.py` → `REGION_CONFIG`:
```python
"Your Region": {
    "language": "th",           # ISO 639-1 language code
    "shelter": "Community Hall, Main Street",
    "emergency_number": "191",
    "subscribers": [],
}
```

Add SMS templates for your language in `alerts/sms.py` → `TEMPLATES`.

### 4. Add subscribers
```python
from alerts.sms import add_subscriber
add_subscriber("Your Region", "+66812345678")
```
Or via the dashboard sidebar.

### 5. Test (dry run — no SMS sent)
```bash
DRY_RUN=1 python pipeline.py
```

### 6. Run the dashboard
```bash
streamlit run dashboard/app.py
```

### 7. Schedule (choose one)

**Option A — run locally:**
```bash
python run_scheduler.py
```

**Option B — cron (Linux/Mac):**
```bash
crontab -e
# Add: 15 */6 * * * cd /path/to/floodwatch && python pipeline.py
```

**Option C — GitHub Actions (free, recommended):**
1. Push repo to GitHub
2. Add secrets: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`, `GEE_SERVICE_ACCOUNT_EMAIL`, `GEE_SERVICE_ACCOUNT_KEY`
3. The workflow in `.github/workflows/floodwatch.yml` runs automatically every 6 hours

---

## Replacing simulation data with real satellite feeds

### Sentinel-1 (soil saturation)
In `pipeline.py` → `fetch_soil_saturation()`, uncomment the Google Earth Engine block:
```python
import ee
ee.Initialize()
img = (ee.ImageCollection('COPERNICUS/S1_GRD')
         .filterBounds(ee.Geometry.Point([lon, lat]))
         .filterDate(...)
         .select('VV').mean())
vv_db = img.reduceRegion(...).getInfo()['VV']
return float(np.clip(1 - (vv_db + 25) / 20, 0, 1))
```

### NOAA GFS (precipitation)
In `pipeline.py` → `_parse_grib_precip()`, replace the simulation with:
```python
import cfgrib, io
ds = cfgrib.open_dataset(io.BytesIO(raw_bytes))
return float(ds['tp'].sel(latitude=lat, longitude=lon, method='nearest'))
```

### Training data
Download historical flood events from the Dartmouth Flood Observatory:
`floodobservatory.colorado.edu` → Global Active Archive → export CSV

In `pipeline.py` → `load_or_train_model()`, replace the synthetic data block with your CSV.

---

## Cost estimate (community of 10,000)

| Item | Cost |
|---|---|
| Twilio SMS (2 alerts/flood event × $0.008) | ~$1.60/event |
| Google Earth Engine | Free (research) |
| NOAA GFS | Free |
| GitHub Actions (pipeline scheduling) | Free |
| Streamlit Community Cloud (dashboard) | Free |
| **Total/month (3 flood events)** | **~$5–10** |

---

## Accuracy benchmarks

Trained on synthetic data (baseline): ~72% F1  
Target with real Dartmouth flood records: 78%+ F1

To evaluate your model:
```python
from sklearn.metrics import classification_report
print(classification_report(y_test, model.predict(X_test)))
```

---

## License
MIT — fork, deploy, adapt freely. If you deploy this for a real community, please open an issue and let us know — we'd love to track real-world impact.
