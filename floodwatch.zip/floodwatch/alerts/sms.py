"""
FloodWatch SMS alerts — Twilio integration
Supports Bengali, English, Tagalog with 2-level threshold logic
"""

import os
import logging
from datetime import datetime

log = logging.getLogger("floodwatch.sms")

# ─── Message Templates ─────────────────────────────────────────────────────────
# Keep under 160 chars so each alert = 1 SMS (cheaper + faster delivery)

TEMPLATES = {
    "YELLOW": {
        "en": (
            "⚠ FLOOD WATCH — {region}\n"
            "Risk: {score}/100. Heavy rain expected ({precip}mm/24h).\n"
            "PREPARE: Move valuables up. Know your evacuation route.\n"
            "Updates every 6hrs. Reply STOP to unsubscribe."
        ),
        "bn": (  # Bengali
            "⚠ বন্যা সতর্কতা — {region}\n"
            "ঝুঁকি: {score}/100। ভারী বৃষ্টি আসছে ({precip}মিমি/২৪ঘণ্টা)।\n"
            "প্রস্তুত থাকুন: মূল্যবান জিনিস উপরে রাখুন। নিরাপদ পথ জানুন।"
        ),
        "tl": (  # Tagalog
            "⚠ BABALA SA BAHA — {region}\n"
            "Panganib: {score}/100. Malakas na ulan ({precip}mm/24h).\n"
            "MAGHANDA: Ilipat ang mahahalagang bagay. Alamin ang ruta ng evakuasyon."
        ),
    },
    "RED": {
        "en": (
            "🚨 FLOOD ALERT — {region}\n"
            "Risk: {score}/100. EVACUATE NOW if in low-lying areas.\n"
            "Go to: {shelter}\n"
            "Emergency: {emergency_number}"
        ),
        "bn": (  # Bengali
            "🚨 বন্যা সতর্কতা — {region}\n"
            "ঝুঁকি: {score}/100। নিচু এলাকায় থাকলে এখনই সরে যান।\n"
            "আশ্রয়কেন্দ্র: {shelter}\n"
            "জরুরি: {emergency_number}"
        ),
        "tl": (  # Tagalog
            "🚨 ALERTO SA BAHA — {region}\n"
            "Panganib: {score}/100. LUMIKAS NA kung nasa mababang lugar.\n"
            "Pumunta sa: {shelter}\n"
            "Emergency: {emergency_number}"
        ),
    },
}

# ─── Region Config ─────────────────────────────────────────────────────────────
# Add your regions here with local emergency info

REGION_CONFIG = {
    "Cox's Bazar South": {
        "language":        "bn",
        "shelter":         "Cox's Bazar Government School, Kolatoli Road",
        "emergency_number": "999 (Bangladesh)",
        "subscribers":     [],  # populated from data/subscribers.json
    },
    "Coastal Chittagong": {
        "language":        "bn",
        "shelter":         "Chittagong Cyclone Shelter, Patenga",
        "emergency_number": "999 (Bangladesh)",
        "subscribers":     [],
    },
}


# ─── Subscriber Management ─────────────────────────────────────────────────────

def load_subscribers(region_name: str) -> list:
    """
    Load subscriber phone numbers for a region from data/subscribers.json.
    Format: {"Cox's Bazar South": ["+8801712345678", ...], ...}
    """
    import json
    from pathlib import Path

    path = Path("data/subscribers.json")
    if not path.exists():
        log.warning("No subscribers.json found. Creating template.")
        template = {r: [] for r in REGION_CONFIG}
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(template, indent=2, ensure_ascii=False))
        return []

    data = json.loads(path.read_text())
    return data.get(region_name, [])


def add_subscriber(region_name: str, phone: str):
    """Add a phone number to a region's subscriber list."""
    import json
    from pathlib import Path

    path = Path("data/subscribers.json")
    data = json.loads(path.read_text()) if path.exists() else {}
    if region_name not in data:
        data[region_name] = []
    if phone not in data[region_name]:
        data[region_name].append(phone)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
        log.info(f"Added {phone} to {region_name}")


# ─── Message Builder ───────────────────────────────────────────────────────────

def build_message(level: str, region_name: str, result: dict) -> str:
    cfg  = REGION_CONFIG.get(region_name, {})
    lang = cfg.get("language", "en")

    template = TEMPLATES[level][lang]
    return template.format(
        region=region_name,
        score=int(result["score"]),
        precip=result["precip_24h_mm"],
        shelter=cfg.get("shelter", "Local emergency shelter"),
        emergency_number=cfg.get("emergency_number", "Local emergency services"),
    )


# ─── Twilio Send ───────────────────────────────────────────────────────────────

def send_sms(to_number: str, message: str, dry_run: bool = False) -> bool:
    """
    Sends an SMS via Twilio. Set env vars:
      TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER
    Set DRY_RUN=1 to log messages without sending (for testing).
    """
    dry_run = dry_run or os.getenv("DRY_RUN", "0") == "1"

    if dry_run:
        log.info(f"[DRY RUN] SMS to {to_number}:\n{message}")
        return True

    account_sid = os.getenv("TWILIO_ACCOUNT_SID")
    auth_token  = os.getenv("TWILIO_AUTH_TOKEN")
    from_number = os.getenv("TWILIO_FROM_NUMBER")

    if not all([account_sid, auth_token, from_number]):
        log.error("Twilio credentials missing. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER.")
        return False

    try:
        from twilio.rest import Client
        client = Client(account_sid, auth_token)
        msg = client.messages.create(body=message, from_=from_number, to=to_number)
        log.info(f"SMS sent to {to_number} — SID: {msg.sid}")
        return True
    except ImportError:
        log.error("twilio not installed. Run: pip install twilio")
        return False
    except Exception as e:
        log.error(f"SMS send failed to {to_number}: {e}")
        return False


# ─── Main Alert Dispatcher ─────────────────────────────────────────────────────

def send_flood_alert(region: dict, result: dict):
    """
    Called by pipeline.py when a region exceeds alert thresholds.
    Loads subscribers, builds localised message, sends to all.
    """
    region_name = region["name"]
    level       = result["level"]

    if level not in ("YELLOW", "RED"):
        return

    subscribers = load_subscribers(region_name)
    if not subscribers:
        log.warning(f"No subscribers for {region_name}. Alert not sent.")
        return

    message = build_message(level, region_name, result)
    log.info(f"Sending {level} alert to {len(subscribers)} subscribers in {region_name}")

    sent, failed = 0, 0
    for number in subscribers:
        if send_sms(number, message):
            sent += 1
        else:
            failed += 1

    log.info(f"Alert dispatch complete: {sent} sent, {failed} failed")


# ─── WhatsApp (same API, different number prefix) ──────────────────────────────

def send_whatsapp_alert(to_number: str, region: dict, result: dict):
    """
    WhatsApp uses the same Twilio API — just prefix 'whatsapp:' to numbers.
    Requires WhatsApp-enabled Twilio number (apply at twilio.com/whatsapp).
    """
    region_name = region["name"]
    level       = result["level"]
    message     = build_message(level, region_name, result)

    # Add dashboard link for WhatsApp users (richer format)
    message += f"\n\n📍 Live map: https://your-dashboard-url/map?region={region_name.replace(' ', '+')}"

    return send_sms(
        to_number=f"whatsapp:{to_number}",
        message=message,
    )


if __name__ == "__main__":
    # Quick test — prints message without sending
    os.environ["DRY_RUN"] = "1"
    test_region = {"name": "Cox's Bazar South", "lat": 21.43, "lon": 92.01}
    test_result = {"score": 85.0, "level": "RED", "precip_24h_mm": 62.5}
    message = build_message("RED", test_region["name"], test_result)
    print("=== RED Alert (Bengali) ===")
    print(message)
    print("\n=== YELLOW Alert (English) ===")
    print(build_message("YELLOW", "Cox's Bazar South", {"score": 65, "level": "YELLOW", "precip_24h_mm": 28.0}))
