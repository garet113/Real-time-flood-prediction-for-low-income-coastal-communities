"""
FloodWatch Dashboard — Streamlit live risk map
Run: streamlit run dashboard/app.py
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    import streamlit as st
    import pandas as pd
    import plotly.express as px
    import plotly.graph_objects as go
except ImportError:
    print("Run: pip install streamlit plotly pandas")
    sys.exit(1)


# ─── Page Config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="FloodWatch",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  [data-testid="stMetricValue"] { font-size: 2rem; }
  .risk-red    { color: #E24B4A; font-weight: 600; }
  .risk-yellow { color: #BA7517; font-weight: 600; }
  .risk-green  { color: #1D9E75; font-weight: 600; }
</style>
""", unsafe_allow_html=True)


# ─── Data Loading ──────────────────────────────────────────────────────────────

@st.cache_data(ttl=360)   # refresh every 6 minutes
def load_history():
    path = Path("data/alert_history.json")
    if not path.exists():
        return []
    return json.loads(path.read_text())


@st.cache_data(ttl=360)
def run_live_score():
    """Run the pipeline and return fresh scores."""
    try:
        from pipeline import load_or_train_model, score_region, CONFIG
        model = load_or_train_model()
        results = []
        for region in CONFIG["target_regions"]:
            result = score_region(model, region["lat"], region["lon"])
            result["region"] = region["name"]
            result["lat"]    = region["lat"]
            result["lon"]    = region["lon"]
            results.append(result)
        return results
    except Exception as e:
        st.error(f"Pipeline error: {e}")
        return []


# ─── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.image("https://via.placeholder.com/200x60?text=FloodWatch", use_column_width=True)
    st.markdown("---")

    st.subheader("⚙️ Settings")
    auto_refresh = st.toggle("Auto-refresh (6h)", value=True)
    show_history = st.toggle("Show history", value=True)

    st.markdown("---")
    st.subheader("📱 Add Subscriber")
    region_sel  = st.selectbox("Region", ["Cox's Bazar South", "Coastal Chittagong"])
    phone_input = st.text_input("Phone number", placeholder="+8801712345678")
    if st.button("Add subscriber"):
        if phone_input.startswith("+") and len(phone_input) > 8:
            from alerts.sms import add_subscriber
            add_subscriber(region_sel, phone_input)
            st.success(f"Added {phone_input}")
        else:
            st.error("Enter a valid international number (+country code)")

    st.markdown("---")
    st.caption("Data: Sentinel-1 SAR + NOAA GFS  |  Alerts via Twilio")


# ─── Main Dashboard ────────────────────────────────────────────────────────────

st.title("🌊 FloodWatch — Real-time Coastal Flood Risk")

col_refresh, col_time = st.columns([1, 3])
with col_refresh:
    if st.button("🔄 Run now"):
        st.cache_data.clear()
with col_time:
    st.caption(f"Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")

st.markdown("---")

# Live scores
with st.spinner("Fetching latest satellite data..."):
    live_results = run_live_score()

if not live_results:
    st.warning("No data available. Check pipeline configuration.")
    st.stop()


# ─── Risk Cards ────────────────────────────────────────────────────────────────

cols = st.columns(len(live_results))
for col, result in zip(cols, live_results):
    with col:
        score = result["score"]
        level = result["level"]
        color = {"RED": "🔴", "YELLOW": "🟡", "GREEN": "🟢"}[level]

        st.metric(
            label=f"{color} {result['region']}",
            value=f"{score}/100",
            delta=f"{'⚠ ALERT SENT' if level != 'GREEN' else 'No alert'}",
            delta_color="inverse" if level != "GREEN" else "off",
        )
        st.caption(
            f"Soil sat: {result['soil_sat']:.0%} · "
            f"Rain: {result['precip_24h_mm']}mm · "
            f"Elev: {result['elevation_pct']}th pct"
        )


# ─── Risk Map ──────────────────────────────────────────────────────────────────

st.subheader("📍 Risk Map")

df_map = pd.DataFrame(live_results)
df_map["color"] = df_map["level"].map({"RED": "red", "YELLOW": "orange", "GREEN": "green"})
df_map["size"]  = df_map["score"] * 0.8 + 20

fig_map = px.scatter_mapbox(
    df_map,
    lat="lat", lon="lon",
    color="level",
    size="score",
    hover_name="region",
    hover_data={"score": True, "precip_24h_mm": True, "soil_sat": True},
    color_discrete_map={"RED": "#E24B4A", "YELLOW": "#EF9F27", "GREEN": "#1D9E75"},
    mapbox_style="carto-positron",
    zoom=7,
    center={"lat": df_map["lat"].mean(), "lon": df_map["lon"].mean()},
    title="Current flood risk by region",
)
fig_map.update_layout(margin={"r": 0, "t": 40, "l": 0, "b": 0}, height=420)
st.plotly_chart(fig_map, use_container_width=True)


# ─── Historical Trend ──────────────────────────────────────────────────────────

if show_history:
    history = load_history()
    if history:
        st.subheader("📈 Risk score history")
        df_hist = pd.DataFrame(history)
        df_hist["timestamp"] = pd.to_datetime(df_hist["timestamp"])
        df_hist = df_hist.sort_values("timestamp")

        fig_hist = px.line(
            df_hist,
            x="timestamp",
            y="score",
            color="region",
            color_discrete_sequence=["#378ADD", "#1D9E75"],
            labels={"score": "Risk score", "timestamp": ""},
        )
        fig_hist.add_hline(y=80, line_dash="dot", line_color="#E24B4A",  annotation_text="Red threshold")
        fig_hist.add_hline(y=60, line_dash="dot", line_color="#EF9F27", annotation_text="Yellow threshold")
        fig_hist.update_layout(height=300, margin={"t": 20})
        st.plotly_chart(fig_hist, use_container_width=True)
    else:
        st.info("No history yet — run the pipeline at least once.")


# ─── Feature Breakdown ─────────────────────────────────────────────────────────

st.subheader("🔬 Feature breakdown")
feat_cols = st.columns(len(live_results))
for col, result in zip(feat_cols, live_results):
    with col:
        st.markdown(f"**{result['region']}**")
        features = {
            "Soil saturation": result["soil_sat"],
            "Rain (24h mm)":   result["precip_24h_mm"] / 100,
            "Elevation pct":   result["elevation_pct"] / 100,
            "Coast dist (km)": result["coast_dist_km"] / 100,
        }
        fig_bar = go.Figure(go.Bar(
            x=list(features.values()),
            y=list(features.keys()),
            orientation="h",
            marker_color="#378ADD",
        ))
        fig_bar.update_layout(
            height=180, margin={"t": 5, "b": 5, "l": 5, "r": 5},
            xaxis={"range": [0, 1]},
        )
        st.plotly_chart(fig_bar, use_container_width=True)
