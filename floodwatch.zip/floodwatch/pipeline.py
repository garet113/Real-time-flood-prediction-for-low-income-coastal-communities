"""
FloodWatch — Real-time flood prediction pipeline
Pulls Sentinel-1 SAR + NOAA GFS → scores risk → sends SMS alerts
"""

import os
import json
import logging
import numpy as np
import requests
from datetime import datetime, timedelta
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("floodwatch")

# ─── Config ────────────────────────────────────────────────────────────────────

CONFIG = {
    "target_regions": [
        {"name": "Cox's Bazar South", "lat": 21.43, "lon": 92.01, "radius_km": 30},
        {"name": "Coastal Chittagong",  "lat": 22.34, "lon": 91.83, "radius_km": 25},
    ],
    "alert_thresholds": {
        "yellow": 60,   # Prepare: move valuables, monitor updates
        "red":    80,   # Evacuate: immediate action required
    },
    "model_path":    "models/flood_model.pkl",
    "history_path":  "data/alert_history.json",
    "gfs_hours_ahead": 24,   # How far ahead to look in GFS forecast
}

# ─── GFS Precipitation Forecast ────────────────────────────────────────────────

def fetch_gfs_precipitation(lat: float, lon: float, hours_ahead: int = 24) -> float:
    """
    Fetches accumulated precipitation forecast from NOAA GFS Open Data API.
    Returns mm of rain expected in the next `hours_ahead` hours.
    Falls back to 0.0 on error (model still runs with other features).
    """
    # Round to nearest 0.25° grid point (GFS resolution)
    lat_r = round(lat * 4) / 4
    lon_r = round(lon * 4) / 4

    # GFS updates at 00, 06, 12, 18 UTC — find most recent run
    now = datetime.utcnow()
    run_hour = (now.hour // 6) * 6
    run_time = now.replace(hour=run_hour, minute=0, second=0, microsecond=0)
    date_str = run_time.strftime("%Y%m%d")
    run_str  = f"{run_hour:02d}"
    fct_str  = f"{hours_ahead:03d}"

    url = (
        f"https://nomads.ncep.noaa.gov/api/cgi-bin/filter_gfs_0p25.pl"
        f"?dir=%2Fgfs.{date_str}%2F{run_str}%2Fatmos"
        f"&file=gfs.t{run_str}z.pgrb2.0p25.f{fct_str}"
        f"&var_APCP=on"
        f"&subregion=&leftlon={lon_r-0.5}&rightlon={lon_r+0.5}"
        f"&toplat={lat_r+0.5}&bottomlat={lat_r-0.5}"
    )

    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        # In production: parse GRIB2 with cfgrib. For now return simulated value.
        # Replace this line with: ds = cfgrib.open_dataset(resp.content); return float(ds.tp.mean())
        precip_mm = _parse_grib_precip(resp.content, lat_r, lon_r)
        log.info(f"GFS precip for ({lat:.2f},{lon:.2f}): {precip_mm:.1f}mm")
        return precip_mm
    except Exception as e:
        log.warning(f"GFS fetch failed for ({lat},{lon}): {e}. Using 0.0mm fallback.")
        return 0.0


def _parse_grib_precip(raw_bytes: bytes, lat: float, lon: float) -> float:
    """
    Stub: replace with cfgrib parsing in production.
    pip install cfgrib eccodes
    import cfgrib, io
    ds = cfgrib.open_dataset(io.BytesIO(raw_bytes))
    return float(ds['tp'].sel(latitude=lat, longitude=lon, method='nearest'))
    """
    # Realistic simulation for testing (remove when cfgrib is installed)
    import hashlib
    seed = int(hashlib.md5(f"{lat}{lon}{datetime.utcnow().date()}".encode()).hexdigest(), 16) % 1000
    rng = np.random.default_rng(seed)
    return float(rng.exponential(scale=15))   # avg 15mm, heavy tail


# ─── Sentinel-1 SAR Soil Saturation ────────────────────────────────────────────

def fetch_soil_saturation(lat: float, lon: float) -> float:
    """
    Returns soil saturation index 0.0 (dry) → 1.0 (fully saturated).

    Production path A — Google Earth Engine (recommended):
      import ee
      ee.Initialize()
      img = (ee.ImageCollection('COPERNICUS/S1_GRD')
               .filterBounds(ee.Geometry.Point([lon, lat]))
               .filterDate((datetime.utcnow()-timedelta(days=12)).strftime('%Y-%m-%d'),
                            datetime.utcnow().strftime('%Y-%m-%d'))
               .filter(ee.Filter.eq('instrumentMode', 'IW'))
               .select('VV').mean())
      vv_db = img.reduceRegion(ee.Reducer.mean(), ee.Geometry.Point([lon,lat]), 100).getInfo()['VV']
      return float(np.clip((vv_db - (-25)) / 20, 0, 1))  # –25dB=wet, –5dB=dry

    Production path B — local rasterio (after downloading .SAFE from dataspace.copernicus.eu):
      import rasterio, rasterio.transform
      with rasterio.open('data/sentinel1_VV.tif') as src:
          row, col = src.index(lon, lat)
          vv = src.read(1)[row, col]
          vv_db = 10 * np.log10(max(vv, 1e-10))
          return float(np.clip(1 - (vv_db + 25) / 20, 0, 1))
    """
    # Simulation for testing — replace with either block above
    import hashlib
    seed = int(hashlib.md5(f"{lat:.1f}{lon:.1f}sat".encode()).hexdigest(), 16) % 1000
    rng = np.random.default_rng(seed)
    return float(np.clip(rng.beta(2, 3), 0, 1))


# ─── Elevation + Coastal Distance (static, computed once) ─────────────────────

def get_terrain_features(lat: float, lon: float) -> dict:
    """
    Returns elevation percentile and coastal distance.
    These are static — pre-compute for your target regions and cache.

    Production:
      pip install elevation richdem
      import elevation, richdem, rasterio
      elevation.clip(bounds=(lon-0.1, lat-0.1, lon+0.1, lat+0.1), output='dem.tif')
      with rasterio.open('dem.tif') as src:
          elev = src.read(1)
          # elevation percentile within 50km radius
          elev_pct = percentileofscore(elev.flatten(), elev[src.index(lon,lat)])
      # Coast distance via shapely + Natural Earth coastline shapefile
    """
    # Pre-computed static values for known regions (add yours here)
    static_terrain = {
        (21.43, 92.01): {"elevation_pct": 12.0, "coast_dist_km": 4.2},
        (22.34, 91.83): {"elevation_pct": 18.5, "coast_dist_km": 8.7},
    }
    key = (round(lat, 2), round(lon, 2))
    if key in static_terrain:
        return static_terrain[key]

    # Fallback: low-lying coastal defaults (conservative = more alerts)
    log.warning(f"No cached terrain for ({lat},{lon}). Using conservative defaults.")
    return {"elevation_pct": 15.0, "coast_dist_km": 10.0}


# ─── Risk Model ────────────────────────────────────────────────────────────────

def load_or_train_model():
    """
    Loads trained model from disk, or trains a baseline if not found.
    Replace training data with real Dartmouth Flood Observatory records.
    """
    import pickle
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline

    model_path = Path(CONFIG["model_path"])
    if model_path.exists():
        with open(model_path, "rb") as f:
            log.info("Loaded existing model.")
            return pickle.load(f)

    log.info("No saved model found — training baseline model...")

    # Synthetic training data (replace with real labeled flood events)
    # Format: [soil_saturation, precip_24h_mm, elevation_pct, coast_dist_km]
    # Label: 1 = flood occurred within 48hrs, 0 = no flood
    rng = np.random.default_rng(42)
    n = 500

    # Flood cases: wet soil + heavy rain + low elevation + close to coast
    flood_X = np.column_stack([
        rng.beta(5, 2, n//2),           # high saturation
        rng.exponential(40, n//2),      # heavy rain
        rng.uniform(0, 25, n//2),       # low elevation
        rng.uniform(0, 15, n//2),       # near coast
    ])
    flood_y = np.ones(n//2)

    # Non-flood cases
    noflood_X = np.column_stack([
        rng.beta(2, 5, n//2),           # low saturation
        rng.exponential(5, n//2),       # light rain
        rng.uniform(20, 100, n//2),     # higher elevation
        rng.uniform(10, 80, n//2),      # further from coast
    ])
    noflood_y = np.zeros(n//2)

    X = np.vstack([flood_X, noflood_X])
    y = np.concatenate([flood_y, noflood_y])

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("clf",    LogisticRegression(C=1.0, max_iter=500)),
    ])
    model.fit(X, y)

    model_path.parent.mkdir(parents=True, exist_ok=True)
    with open(model_path, "wb") as f:
        pickle.dump(model, f)

    log.info(f"Baseline model trained and saved to {model_path}")
    log.warning("⚠ Replace synthetic training data with real flood records before production.")
    return model


def score_region(model, lat: float, lon: float) -> dict:
    """Scores a single lat/lon. Returns risk dict with score + alert level."""
    saturation   = fetch_soil_saturation(lat, lon)
    precip_24h   = fetch_gfs_precipitation(lat, lon, CONFIG["gfs_hours_ahead"])
    terrain      = get_terrain_features(lat, lon)

    features = np.array([[
        saturation,
        precip_24h,
        terrain["elevation_pct"],
        terrain["coast_dist_km"],
    ]])

    prob  = model.predict_proba(features)[0][1]
    score = round(prob * 100, 1)

    if score >= CONFIG["alert_thresholds"]["red"]:
        level = "RED"
    elif score >= CONFIG["alert_thresholds"]["yellow"]:
        level = "YELLOW"
    else:
        level = "GREEN"

    return {
        "score":          score,
        "level":          level,
        "soil_sat":       round(saturation, 3),
        "precip_24h_mm":  round(precip_24h, 1),
        "elevation_pct":  terrain["elevation_pct"],
        "coast_dist_km":  terrain["coast_dist_km"],
        "timestamp":      datetime.utcnow().isoformat(),
    }


# ─── Main Run ──────────────────────────────────────────────────────────────────

def run():
    log.info("=== FloodWatch run started ===")
    model   = load_or_train_model()
    results = []

    for region in CONFIG["target_regions"]:
        log.info(f"Scoring: {region['name']}")
        result = score_region(model, region["lat"], region["lon"])
        result["region"] = region["name"]
        results.append(result)

        log.info(
            f"  {region['name']}: score={result['score']} "
            f"level={result['level']} "
            f"precip={result['precip_24h_mm']}mm "
            f"saturation={result['soil_sat']}"
        )

        if result["level"] in ("YELLOW", "RED"):
            from alerts.sms import send_flood_alert
            send_flood_alert(region, result)

    # Save run history
    history_path = Path(CONFIG["history_path"])
    history_path.parent.mkdir(parents=True, exist_ok=True)
    history = json.loads(history_path.read_text()) if history_path.exists() else []
    history.extend(results)
    history_path.write_text(json.dumps(history[-1000:], indent=2))  # keep last 1000 runs

    log.info("=== Run complete ===")
    return results


if __name__ == "__main__":
    run()
