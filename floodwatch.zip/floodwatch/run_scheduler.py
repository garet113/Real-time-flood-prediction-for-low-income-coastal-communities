"""
FloodWatch scheduler — runs the pipeline every 6 hours
aligned to NOAA GFS update cycle (00, 06, 12, 18 UTC).

Usage:
  python run_scheduler.py              # run continuously
  python run_scheduler.py --once       # single run and exit (for cron)

Cron alternative (add to crontab with: crontab -e):
  0 */6 * * * cd /path/to/floodwatch && python pipeline.py >> logs/floodwatch.log 2>&1

GitHub Actions alternative: see .github/workflows/floodwatch.yml
"""

import sys
import logging
import time
from datetime import datetime, timezone

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/floodwatch.log"),
    ]
)
log = logging.getLogger("floodwatch.scheduler")


def run_once():
    from pipeline import run
    log.info(f"Pipeline triggered at {datetime.now(timezone.utc).isoformat()}")
    results = run()
    for r in results:
        log.info(f"  {r['region']}: {r['level']} ({r['score']}/100)")
    return results


def run_scheduled():
    """Runs every 6 hours, offset by 15 minutes to let GFS data propagate."""
    import schedule

    schedule.every(6).hours.do(run_once)
    log.info("Scheduler started — running every 6 hours.")
    log.info("Next run: within 6 hours. Press Ctrl+C to stop.")

    run_once()  # immediate first run

    while True:
        schedule.run_pending()
        time.sleep(60)


if __name__ == "__main__":
    from pathlib import Path
    Path("logs").mkdir(exist_ok=True)

    if "--once" in sys.argv:
        run_once()
    else:
        run_scheduled()
